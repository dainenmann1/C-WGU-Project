#include <iostream>
#include <string>
using namespace std;

// Define enumerated data type for degree
enum DegreeProgram {
	SECURITY,
	NETWORK,
	SOFTWARE
};